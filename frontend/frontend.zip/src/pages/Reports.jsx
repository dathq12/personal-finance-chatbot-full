import { useState } from 'react';
import Layout from '../components/Layout/Layout';

const ReportPage = () => {

    return (
        <Layout>

        </Layout>
    )
}

export default ReportPage;