import { useState } from 'react';
import Layout from '../components/Layout/Layout';

const ManualEntry = () => {
  const [type, setType] = useState('Thu');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState('');
  const [note, setNote] = useState('');
  const [dateTime, setDateTime] = useState(new Date().toISOString().slice(0, 16));
  const [entries, setEntries] = useState([]);

  const handleSave = () => {
    const newEntry = {
      id: Date.now(),
      type,
      amount,
      category,
      note,
      dateTime,
    };
    setEntries([newEntry, ...entries]);
    setAmount('');
    setCategory('');
    setNote('');
    setDateTime(new Date().toISOString().slice(0, 16));
  };

  return (
    <Layout>
      <div className="flex w-full h-dvh overflow-hidden">
        <div className="flex-1 bg-white px-8 py-6 overflow-y-auto text-sm">
          <h2 className="text-base font-semibold mb-6">Nhập thu/chi</h2>

          <div className="space-y-5 max-w-md">
            <div>
              <label className="block font-medium mb-1">Loại</label>
              <select
                className="w-full border rounded-lg px-4 py-2"
                value={type}
                onChange={(e) => setType(e.target.value)}
              >
                <option value="Thu">Thu</option>
                <option value="Chi">Chi</option>
              </select>
            </div>

            <div>
              <label className="block font-medium mb-1">Số tiền</label>
              <input
                type="number"
                className="w-full border rounded-lg px-4 py-2"
                placeholder="₫"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
              />
            </div>

            <div>
              <label className="block font-medium mb-1">Danh mục</label>
              <input
                type="text"
                className="w-full border rounded-lg px-4 py-2"
                placeholder="Chọn danh mục"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
              />
            </div>

            <div>
              <label className="block font-medium mb-1">Lý do</label>
              <input
                type="text"
                className="w-full border rounded-lg px-4 py-2"
                placeholder="Nhập lý do chi tiết"
                value={note}
                onChange={(e) => setNote(e.target.value)}
              />
            </div>

            <div>
              <label className="block font-medium mb-1">Thời gian</label>
              <input
                type="datetime-local"
                className="w-full border rounded-lg px-4 py-2"
                value={dateTime}
                onChange={(e) => setDateTime(e.target.value)}
              />
            </div>

            <div className="pt-4">
              <button
                onClick={handleSave}
                className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                Lưu
              </button>
            </div>
          </div>

          {/* Danh sách thu/chi đã tạo */}
          <div className="mt-10">
            <h3 className="text-base font-semibold mb-6">Danh sách đã ghi nhận</h3>
            <ul className="space-y-2">
              {entries.map((entry) => (
                <li key={entry.id} className="border rounded-lg p-4">
                  <div><strong>{entry.type}</strong> • {entry.category}</div>
                  <div>Số tiền: {entry.amount}₫</div>
                  <div>Lý do: {entry.note}</div>
                  <div>Thời gian: {new Date(entry.dateTime).toLocaleString()}</div>
                </li>
              ))}
              {entries.length === 0 && <li className="text-gray-500">Chưa có dữ liệu</li>}
            </ul>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default ManualEntry;